(***test_stack.ml**)

#use "stack.ml";;

let test_stack () = 