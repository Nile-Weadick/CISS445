(***test_grammar.ml**)
Printf.printf "%s" ^ (expr_to_string (Int 42));;